#!/bin/bash
set -e

showHelp(){
  echo "This script will build admin secret, certificate, ingress/route and update value file based on customer input."
  echo ""
  echo "Usage:"
  echo "./prepare-bastudio.sh -i <input_value_file> -o <output_folder>"
  echo "Flags:"
  echo "     -i input value file."
  echo "     -o output folder for generated files"
  echo "     -h show help"
  echo ""
}


while getopts "i:o:h" option
do
  case $option in
    i)
      inputFile=$OPTARG
      ;;
    o)
      outputFolder=$OPTARG
      ;;
    h)
      showHelp="true"
  esac
done

if [[ "$showHelp" == "true" ]]
then
  showHelp;
  exit 0;
fi

command -v helm >/dev/null 2>&1 || { echo >&2 "Helm is required to run this script. Please install helm and set helm in path."; exit 1; }

if [[ -z "$inputFile" ]]; then
  echo "======================="
  echo "ERROR: Input value file is required. Please input with parameter -i."
  echo "======================="
  showHelp
  exit 1;
fi

if [[ ! -e $inputFile ]]; then
  echo "Input file does not exitsed. Please check the ${inputFile} is correct."
  exit 1
fi

if [[ -z "$outputFolder" ]]; then
  echo "WARNING: Output folder does not set. Will use $(pwd)/output folder as output folder."
  outputFolder="$(pwd)/output"
  echo "Output fodler settled to ${outputFolder}"
fi

if [[ ! -d $outputFolder ]]; then
  echo "Target folder does not existed. Creating one ${outputFolder}"
  mkdir -p $outputFolder
else
  echo "Target folder does existing. Files may be overwritten."
fi

outputFolder=$(dirname ${outputFolder})/$(basename ${outputFolder})

helm template ${0%/*}/aae-helper.tgz --values $inputFile --output-dir $outputFolder --notes
tail -n +3 ${outputFolder}/aae-helper/templates/db-script.sql > ${outputFolder}/aae-helper/templates/db-script.sqlnew
mv ${outputFolder}/aae-helper/templates/db-script.sqlnew ${outputFolder}/aae-helper/templates/db-script.sql
cat $outputFolder/aae-helper/templates/NOTES.txt

echo ""